
const sendNotification = (message) => {
    console.log("Notification sent:", message);
};

module.exports = { sendNotification };
