
const getOrders = () => {
    return [{ id: 201, userId: 1, productId: 101, status: "Shipped" }];
};

module.exports = { getOrders };
