
const getProducts = () => {
    return [{ id: 101, name: "Laptop", price: 1200 }];
};

module.exports = { getProducts };
