const getUsers = () => {
    return [{ id: 1, name: "John Doe" }];
};

module.exports = { getUsers };
