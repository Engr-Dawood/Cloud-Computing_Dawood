# monolithic-ecs-microservices
Node.js monolithic app with 5 services
